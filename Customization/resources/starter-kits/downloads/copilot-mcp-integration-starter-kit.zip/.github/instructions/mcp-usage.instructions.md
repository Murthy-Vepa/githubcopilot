---
applyTo: "**/*"
---
# MCP usage boundaries

- Use only approved MCP servers.
- Prefer read-only tools for discovery and analysis.
- Confirm the data classification before sending repository or customer data.
- Do not approve destructive or external write operations without human review.
- Report the server, tool, and expected side effect before using a write-capable tool.
