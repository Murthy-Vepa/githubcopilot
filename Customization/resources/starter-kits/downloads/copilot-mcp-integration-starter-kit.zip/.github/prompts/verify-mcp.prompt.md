---
description: Verify that an approved MCP server is discoverable and safely scoped.
---
# MCP verification

1. List the available tools and resources.
2. Identify which operations are read-only and which can write.
3. Test one harmless read-only request.
4. State what data was accessed and what side effect occurred.
5. Stop if the server exposes unexpected permissions or sensitive data.

Do not call destructive tools during this verification.
