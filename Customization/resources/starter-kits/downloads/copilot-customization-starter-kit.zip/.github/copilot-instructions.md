# Repository guidance

- Inspect the existing architecture before proposing changes.
- Follow the repository's established naming, testing, and error-handling conventions.
- Prefer the smallest change that satisfies the requirement.
- Add or update focused tests for behavior changes.
- Run the documented validation commands before reporting completion.
- Do not expose secrets or modify generated files unless requested.
