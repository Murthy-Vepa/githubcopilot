---
description: Create a repository-aware implementation plan for a feature.
agent: planner
---
# Feature planning

Analyze the requested feature and produce:

1. A concise understanding of the current behavior.
2. The files and symbols that should change.
3. The smallest implementation sequence.
4. Risks, assumptions, and open questions.
5. Focused validation commands.

Do not edit files. Say when repository evidence is insufficient.
