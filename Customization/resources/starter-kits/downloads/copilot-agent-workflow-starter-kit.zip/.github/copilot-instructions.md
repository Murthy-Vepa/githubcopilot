# Agent workflow conventions

- State the current hypothesis before editing.
- Keep handoffs explicit: objective, files, risks, and validation.
- Planners do not edit; reviewers prioritize defects and regressions.
- Builders must run focused validation before reporting completion.
- Stop and request clarification when requirements or permissions are ambiguous.
